{
  "timeZone": "Asia/Kuching",
  "dependencies": {
    "enabledAdvancedServices": [
      {
        "userSymbol": "Analytics",
        "version": "v3",
        "serviceId": "analytics"
      },
      {
        "userSymbol": "Sheets",
        "version": "v4",
        "serviceId": "sheets"
      }
    ]
  },
  "exceptionLogging": "STACKDRIVER",
  "runtimeVersion": "V8"
}