function salesDataAnalysis() {
  var spreadsheetUrl = "https://docs.google.com/spreadsheets/d/13fiaYAOEDzX5IvLZbrli4-0ZZVb0y6Cnmw2nBeQsglA/edit?gid=0#gid=0";
  var spreadsheet = SpreadsheetApp.openByUrl(spreadsheetUrl);
  var sheet = spreadsheet.getSheetByName("Google Hackaton");

  if (!sheet) {
    Logger.log("Error: Sheet 'Google Hackaton' not found in the spreadsheet.");
    return;
  }

  var data = sheet.getDataRange().getValues();

  var totalSales = 0;
  var totalUnits = 0;
  var topProducts = {};
  var topCustomers = {};

  for (var i = 1; i < data.length; i++) {
    var rowData = data[i];
    Logger.log("Processing row " + (i+1) + ": " + JSON.stringify(rowData));

    var date = parseDate(rowData[2]);
    var productId = rowData[0];
    var quantity = parseFloat(rowData[3]);
    var saleAmount = parseSaleAmount(rowData[4]);
    var customerName = rowData[7];

    if (!date || isNaN(quantity) || isNaN(saleAmount) || !customerName) {
      Logger.log("Invalid data at row " + (i+1) + ". Skipping this row.");
      continue;
    }

    totalSales += saleAmount;
    totalUnits += quantity;

    updateTopItems(topProducts, productId, quantity, saleAmount);
    updateTopItems(topCustomers, customerName, quantity, saleAmount);
  }

  var resultSheet = spreadsheet.getSheetByName("Analysis Results");
  if (!resultSheet) {
    resultSheet = spreadsheet.insertSheet("Analysis Results");
  } else {
    resultSheet.clear();
  }

  writeResults(resultSheet, totalSales, totalUnits, topProducts, topCustomers);

  // Predict future sales
  predictFutureSales(data, resultSheet);
}

function parseDate(dateValue) {
  if (dateValue instanceof Date) {
    return dateValue;
  } else if (typeof dateValue === 'string') {
    var date = new Date(dateValue);
    if (!isNaN(date.getTime())) {
      return date;
    }
  }
  Logger.log("Invalid date: " + dateValue);
  return null;
}

function parseSaleAmount(saleValue) {
  if (typeof saleValue === 'number') {
    return saleValue;
  } else if (typeof saleValue === 'string') {
    return parseFloat(saleValue.replace(/[^0-9.-]+/g,""));
  }
  Logger.log("Invalid sale amount: " + saleValue);
  return NaN;
}

function updateTopItems(items, key, quantity, saleAmount) {
  if (items[key]) {
    items[key].quantity += quantity;
    items[key].saleAmount += saleAmount;
  } else {
    items[key] = {
      quantity: quantity,
      saleAmount: saleAmount
    };
  }
}

function writeResults(sheet, totalSales, totalUnits, topProducts, topCustomers) {
  sheet.appendRow(["Total Sales", totalSales.toFixed(2)]);
  sheet.appendRow(["Total Units Sold", totalUnits]);

  sheet.appendRow([""]);
  sheet.appendRow(["Top 5 Products"]);
  sheet.appendRow(["Product ID", "Sales", "Quantity"]);
  writeTopItems(sheet, topProducts, 5);

  sheet.appendRow([""]);
  sheet.appendRow(["Top 5 Customers"]);
  sheet.appendRow(["Customer Name", "Sales", "Quantity"]);
  writeTopItems(sheet, topCustomers, 5);
}

function writeTopItems(sheet, items, limit) {
  var itemsArray = Object.entries(items);
  itemsArray.sort((a, b) => b[1].saleAmount - a[1].saleAmount);
  for (var j = 0; j < limit && j < itemsArray.length; j++) {
    var key = itemsArray[j][0];
    var data = itemsArray[j][1];
    sheet.appendRow([key, data.saleAmount.toFixed(2), data.quantity]);
  }
}

function predictFutureSales(data, resultSheet) {
  // Extract date and sales data
  var dates = [];
  var sales = [];
  for (var i = 1; i < data.length; i++) {
    var date = parseDate(data[i][2]);
    var saleAmount = parseSaleAmount(data[i][4]);
    
    if (date && !isNaN(saleAmount)) {
      dates.push(date);
      sales.push(saleAmount);
    }
  }

  if (dates.length === 0 || sales.length === 0) {
    Logger.log("Error: No valid data for prediction.");
    return;
  }

  // Convert dates to timestamps
  var timestamps = dates.map(function(date) {
    return date.getTime();
  });

  // Simple linear regression model
  var n = timestamps.length;
  var sumX = 0, sumY = 0, sumXY = 0, sumXX = 0;
  for (var i = 0; i < n; i++) {
    sumX += timestamps[i];
    sumY += sales[i];
    sumXY += timestamps[i] * sales[i];
    sumXX += timestamps[i] * timestamps[i];
  }
  var slope = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);
  var intercept = (sumY - slope * sumX) / n;

  // Predict sales for the next month
  var futureDates = [];
  var today = new Date();
  for (var i = 1; i <= 30; i++) {
    var futureDate = new Date(today);
    futureDate.setDate(today.getDate() + i);
    futureDates.push(futureDate);
  }

  var futureSales = futureDates.map(function(date) {
    var timestamp = date.getTime();
    return slope * timestamp + intercept;
  });

  // Output prediction results to the sheet
  resultSheet.appendRow([""]);
  resultSheet.appendRow(["Future Sales Predictions"]);
  resultSheet.appendRow(["Date", "Predicted Sales"]);
  for (var i = 0; i < futureDates.length; i++) {
    resultSheet.appendRow([futureDates[i].toLocaleDateString(), futureSales[i].toFixed(2)]);
  }
}